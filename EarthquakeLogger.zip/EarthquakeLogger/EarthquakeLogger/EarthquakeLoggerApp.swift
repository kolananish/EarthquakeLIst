//
//  EarthquakeLoggerApp.swift
//  EarthquakeLogger
//
//  Created by Anish Kolan on 4/5/23.
//

import SwiftUI

@main
struct EarthquakeLoggerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
