import Foundation
import SwiftUI
import CoreLocation

struct EarthquakeData: Codable {
    let earthquakes: [Earthquake]
}

struct Earthquake: Codable {
    let datetime: String
    let depth: Double
    let magnitude: Double
    let lat: Double
    let lng: Double
    let src: String
}

class APIManager {
    static let shared = APIManager()
    private init() {}
    
    let apiKey = "anishk"
    
    func fetchEarthquakeData(north: Double, south: Double, east: Double, west: Double, completion: @escaping (Result<[Earthquake], Error>) -> Void) {
        let url = URL(string: "http://api.geonames.org/earthquakesJSON?formatted=true&north=\(north)&south=\(south)&east=\(east)&west=\(west)&username=\(apiKey)&style=full")!
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            
            guard let data = data else {
                completion(.failure(NSError(domain: "", code: 0, userInfo: [NSLocalizedDescriptionKey: "Data not found"])))
                return
            }
            
            do {
                let decodedData = try JSONDecoder().decode(EarthquakeData.self, from: data)
                let earthquakes = decodedData.earthquakes
                completion(.success(earthquakes))
            } catch {
                completion(.failure(error))
            }
        }
        task.resume()
    }
}

struct ContentView: View {
    @State var cityName = ""
    @State var north = 0.0
    @State var south = 0.0
    @State var east = 0.0
    @State var west = 0.0
    @State var earthquakes: [Earthquake] = []

    var body: some View {
        VStack {
            Spacer()
            HStack {
                Spacer()
                Text("Enter City:")
                    .font(.title3)
                TextField("City Name", text: $cityName)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                Spacer()
            }

            Button("Get Earthquakes", action: {
                forwardGeocoding(addressStr: cityName) { latitude, longitude in
                    if let latitude = latitude, let longitude = longitude {
                        north = latitude + 10
                        south = latitude - 10
                        east = longitude - 10
                        west = longitude + 10
                        earthquakes = []
                        APIManager.shared.fetchEarthquakeData(north: north, south: south, east: east, west: west) { result in
                            switch result {
                            case .success(let earthquakes):
                                self.earthquakes = earthquakes
                            case .failure(let error):
                                print(error.localizedDescription)
                            }
                        }
                    } else {
                        print("Unable to geocode address")
                    }
                }
            })

            List(earthquakes.prefix(30), id: \.datetime) { earthquake in
                VStack(alignment: .leading) {
                    Text("Date & Time: \(earthquake.datetime)")
                    Text("Magnitude: \(earthquake.magnitude)")
                }
            }
        }
    }

    func forwardGeocoding(addressStr: String, completion: @escaping (Double?, Double?) -> Void) {
        let addressString = addressStr
        CLGeocoder().geocodeAddressString(
            addressString,
            completionHandler: { (placemarks, error) in
                if error != nil {
                    print("Geocode failed: \(error!.localizedDescription)")
                } else if let placemark = placemarks?.first {
                    let location = placemark.location
                    let coords = location!.coordinate
                    completion(coords.latitude, coords.longitude)
                }
            })
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
